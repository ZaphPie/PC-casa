from .figuras import *
from .menu import *
from .funciones import *
